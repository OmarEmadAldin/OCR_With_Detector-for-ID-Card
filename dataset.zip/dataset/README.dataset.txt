# Egyptian ID Detectr > 2024-07-04 7:40pm
https://universe.roboflow.com/omartamer0/egyptian-id-detectr

Provided by a Roboflow user
License: CC BY 4.0

